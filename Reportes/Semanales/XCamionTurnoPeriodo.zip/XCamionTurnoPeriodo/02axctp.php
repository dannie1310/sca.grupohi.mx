<?php
  include("../../../Clases/Conexiones/Conexion.php");
	include("../../../inc/funciones/formato_fecha_ingles.php");
	
  $fi    = $_POST["fi"];
	$ff    = $_POST["ff"];
  $fi_fi = formato_fecha_ingles($_POST["fi"]);
	$ff_fi = formato_fecha_ingles($_POST["ff"]);
	
	$link = conectar();
	$SQL = "
	         (
						SELECT
							1 as turno,
							economico,
							DATE_FORMAT(fechallegada, '%e/%m/%Y') as fechallegada,
							cubicacion,
							COUNT(idviaje) as viajes,
							material,
							idorigen,
							origen,
							idtiro,
							destino,
							distancia as distancia,
							SUM(volumenprimerkm) as volumenprimerkm,
							SUM(volumenkmsubsecuentes) as volumenkmsubsecuentes,
							SUM(volumenkmadicionales) as volumenkmadicionales,
							SUM(volumen) as volumen,
							SUM(importeprimerkm) as importeprimerkm,
							SUM(importekmsubsecuentes) as importekmsubsecuentes,
							SUM(importekmadicionales) as importekmadicionales,
							SUM(importe) as importe
						FROM
							vw_viajes
						WHERE
							fechallegada BETWEEN '".$fi_fi."' AND '".$ff_fi."'
							AND horallegada BETWEEN '07:00:01' AND '18:00:00'
						GROUP BY
							turno,
							economico,
							fechallegada,
							cubicacion,
							material,
							idorigen,
							origen,
							idtiro,
							destino
						ORDER BY
						turno,
							economico,
							fechallegada,
							cubicacion,
							material,
							origen,
							destino,
							distancia
						)
						UNION ALL
						(
						SELECT
							2 as turno,
							economico,
							DATE_FORMAT(fechallegada, '%e/%m/%Y') as fechallegada,
							cubicacion,
							COUNT(idviaje) as viajes,
							material,
							idorigen,
							origen,
							idtiro,
							destino,
							distancia  as distancia,
							SUM(volumenprimerkm) as volumenprimerkm,
							SUM(volumenkmsubsecuentes) as volumenkmsubsecuentes,
							SUM(volumenkmadicionales) as volumenkmadicionales,
							SUM(volumen) as volumen,
							SUM(importeprimerkm) as importeprimerkm,
							SUM(importekmsubsecuentes) as importekmsubsecuentes,
							SUM(importekmadicionales) as importekmadicionales,
							SUM(importe) as importe
						FROM
							vw_viajes
						WHERE
							(fechallegada BETWEEN '".$fi_fi."' AND '".$ff_fi."'
							AND horallegada BETWEEN '18:00:01' AND '23:59:59')
							OR
							(fechallegada BETWEEN DATE_ADD('".$fi_fi."', INTERVAL 1 DAY) AND DATE_ADD('".$ff_fi."', INTERVAL 1 DAY)
							AND horallegada BETWEEN '00:00:00' AND '07:00:00')
						GROUP BY
							turno,
							economico,
							fechallegada,
							cubicacion,
							material,
							idorigen,
							origen,
							idtiro,
							destino
						ORDER BY
						  turno,
							economico,
							fechallegada,
							cubicacion,
							material,
							origen,
							destino,
							distancia
						)
						ORDER BY
						  turno,
							economico,
							fechallegada,
							cubicacion,
							material,
							origen,
							destino,
							distancia
	";
	echo $SQL;
	$result = mysql_query($SQL, $link);
	
	$contador_viajes = 0;
	
	while($row = mysql_fetch_array($result))
	{
		$contador_viajes = $contador_viajes +1;
		$viajes[1][$contador_viajes] = $row["turno"];
		$viajes[2][$contador_viajes] = $row["economico"];
		$viajes[3][$contador_viajes] = $row["fechallegada"];
		$viajes[4][$contador_viajes] = $row["cubicacion"];
		$viajes[5][$contador_viajes] = $row["viajes"];
		$viajes[6][$contador_viajes] = $row["material"];
		$viajes[7][$contador_viajes] = $row["idorigen"];
		$viajes[8][$contador_viajes] = $row["origen"];
		$viajes[9][$contador_viajes] = $row["idtiro"];
		$viajes[10][$contador_viajes] = $row["destino"];
		$viajes[11][$contador_viajes] = $row["distancia"];
		$viajes[12][$contador_viajes] = $row["volumenprimerkm"];
		$viajes[13][$contador_viajes] = $row["volumenkmsubsecuentes"];
		$viajes[14][$contador_viajes] = $row["volumenkmadicionales"];
		$viajes[15][$contador_viajes] = $row["volumen"];
		$viajes[16][$contador_viajes] = $row["importeprimerkm"];
		$viajes[17][$contador_viajes] = $row["importekmsubsecuentes"];
		$viajes[18][$contador_viajes] = $row["importekmadicionales"];
		$viajes[19][$contador_viajes] = $row["importe"];
		
		//Totales
		$total_viajes 			= $total_viajes 			+ $row["viajes"];
		
		$total_vol_primerkm = $total_vol_primerkm + $row["volumenprimerkm"];
		$total_vol_kmsub 	= $total_vol_kmsub 		+ $row["volumenkmsubsecuentes"];
		$total_vol_kmadic 	= $total_vol_kmadic 	+ $row["volumenkmadicionales"];
		$total_volumen			= $total_volumen			+ $row["volumen"];
		
		$total_imp_primerkm = $total_imp_primerkm + $row["importeprimerkm"];
		$total_imp_kmsub 		= $total_imp_kmsub 		+ $row["importekmsubsecuentes"];
		$total_imp_kmadic 	= $total_imp_kmadic 	+ $row["importekmadicionales"];
		$total_importe			= $total_importe			+ $row["importe"];
		
	}

?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
  <!--
    .Estilo1 { color: #FF0000; }
    .Estilo2 { font-size: 1px; color: #FFFFFF; }
    .Estilo4 { font-size: 1px; color: #cccccc; }
body,td,th {
	font-family: Lucida Sans, Calibri, Trebuchet MS;
	font-size: 10px;
	color: #000;
}
  -->
</style>
</head>

<body>
<table width="0" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td colspan="20"><font style="font-family:'Lucida Sans', Calibri, 'Trebuchet MS'; font-weight:bold; font-size:14px;">Acarreos Ejecutados por Cami&oacute;n y Turno del <?php echo $fi; ?> al <?php echo $ff; ?></font></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td colspan="20" align="right"><font color="#000000" style="font-family:'Trebuchet MS'; font-weight:bold;font-size:12px;"><?php echo 'FECHA DE CONSULTA '.date("d-m-Y")."/".date("H:i:s",time()); ?></font></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td colspan="3" align="center" bgcolor="#000000" style="color:#FFF"><strong>Volumen</strong></td>
    <td colspan="3" align="center" bgcolor="#000000" style="color:#FFF"><strong>Importe</strong></td>
    <td>&nbsp;</td>
    <td colspan="2" align="center" bgcolor="#000000" style="color:#FFF"><strong>Total</strong></td>
  </tr>
  <tr>
    <td align="center" bgcolor="#000000" style="color:#FFF"><strong>Turno</strong></td>
    <td align="center" bgcolor="#000000" style="color:#FFF"><strong>Económico</strong></td>
    <td align="center" bgcolor="#000000" style="color:#FFF"><strong>Fecha</strong></td>
    <td align="center" bgcolor="#000000" style="color:#FFF"><strong>Cuicación</strong></td>
    <td align="center" bgcolor="#000000" style="color:#FFF"><strong>Viajes</strong></td>
    <td align="center" bgcolor="#000000" style="color:#FFF"><strong>Material</strong></td>
    <td colspan="2" align="center" bgcolor="#000000" style="color:#FFF"><strong>Origen</strong></td>
    <td colspan="2" align="center" bgcolor="#000000" style="color:#FFF"><strong>Destino</strong></td>
    <td align="center" bgcolor="#000000" style="color:#FFF"><strong>Distancia</strong></td>
    <td align="center" bgcolor="#333333" style="color:#FFF"><strong>1er. KM</strong></td>
    <td align="center" bgcolor="#333333" style="color:#FFF"><strong>KM Subs.</strong></td>
    <td align="center" bgcolor="#333333" style="color:#FFF"><strong>KM Adc.</strong></td>
    <td align="center" bgcolor="#333333" style="color:#FFF"><strong>1er. KM</strong></td>
    <td align="center" bgcolor="#333333" style="color:#FFF"><strong>KM Subs.</strong></td>
    <td align="center" bgcolor="#333333" style="color:#FFF"><strong>KM Adc.</strong></td>
    <td align="center">&nbsp;</td>
    <td align="center" bgcolor="#333333" style="color:#FFF"><strong>Volumen</strong></td>
    <td align="center" bgcolor="#333333" style="color:#FFF"><strong>Importe</strong></td>
  </tr>
  <?php
    for($a=1; $a <= count($viajes[1]); $a++)
		{
	?>
  <tr>
    <td width="50" align="center">
		<?php 
		  if($viajes[1][$a] != $viajes[1][$a-1])
		    echo $viajes[1][$a]; 
		?>
    </td>
    <td width="50" align="center">
		<?php 
		  if($viajes[2][$a] != $viajes[2][$a-1])
			  echo $viajes[2][$a]; 
		?>
    </td>
    <td width="70">
		<?php 
		    echo $viajes[3][$a]; 
	  ?>
    </td>
    <td width="50" align="center"><?php echo $viajes[4][$a]; ?></td>
    <td width="70" align="center"><?php echo $viajes[5][$a]; ?></td>
    <td width="100"><?php echo $viajes[6][$a]; ?></td>
    <td width="30" align="left"><?php echo 'B-'.$viajes[7][$a]; ?></td>
    <td width="200" align="left"><?php echo $viajes[8][$a]; ?></td>
    <td width="30" align="left"><?php echo 'T-'.$viajes[9][$a]; ?></td>
    <td width="200" align="left"><?php echo $viajes[10][$a]; ?></td>
    <td width="50" align="center"><?php echo $viajes[11][$a]; ?></td>
    <td width="50" align="right"><?php echo number_format($viajes[12][$a], 0, '.', ','); ?></td>
    <td width="50" align="right"><?php echo number_format($viajes[13][$a], 0, '.', ','); ?></td>
    <td width="50" align="right"><?php echo number_format($viajes[14][$a], 0, '.', ','); ?></td>
    <td width="50" align="right"><?php echo number_format($viajes[16][$a], 2, '.', ','); ?></td>
    <td width="50" align="right"><?php echo number_format($viajes[17][$a], 2, '.', ','); ?></td>
    <td width="50" align="right"><?php echo number_format($viajes[18][$a], 2, '.', ','); ?></td>
    <td width="10">&nbsp;</td>
    <td width="70" align="right"><?php echo number_format($viajes[15][$a], 0, '.', ','); ?></td>
    <td width="70" align="right"><?php echo number_format($viajes[19][$a], 2, '.', ','); ?></td>
  </tr>
  <?php
	  $subtotal_fecha = $subtotal_fecha + $viajes[5][$a];
		if(($viajes[3][$a]!=$viajes[3][$a+1]))
		{
	?>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td bgcolor="#CCCCCC">&nbsp;</td>
    <td bgcolor="#CCCCCC">&nbsp;</td>
    <td bgcolor="#CCCCCC" align="center"><?php echo number_format($subtotal_fecha, 0, '.', ','); ?></td>
    <td bgcolor="#CCCCCC">&nbsp;</td>
    <td bgcolor="#CCCCCC">&nbsp;</td>
    <td bgcolor="#CCCCCC">&nbsp;</td>
    <td bgcolor="#CCCCCC">&nbsp;</td>
    <td bgcolor="#CCCCCC">&nbsp;</td>
    <td bgcolor="#CCCCCC">&nbsp;</td>
    <td bgcolor="#CCCCCC">&nbsp;</td>
    <td bgcolor="#CCCCCC">&nbsp;</td>
    <td bgcolor="#CCCCCC">&nbsp;</td>
    <td bgcolor="#CCCCCC">&nbsp;</td>
    <td bgcolor="#CCCCCC">&nbsp;</td>
    <td bgcolor="#CCCCCC">&nbsp;</td>
    <td>&nbsp;</td>
    <td bgcolor="#CCCCCC">&nbsp;</td>
    <td bgcolor="#CCCCCC">&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
    <?php
		  $subtotal_fecha = 0;
	  }
	?>
  <?php
	//Subtotales por economico
			if(($viajes[2][$a]!=$viajes[2][$a+1]))
			{
	?>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td bgcolor="#999999">&nbsp;</td>
    <td bgcolor="#999999">&nbsp;</td>
    <td bgcolor="#999999">&nbsp;</td>
    <td bgcolor="#999999">&nbsp;</td>
    <td bgcolor="#999999">&nbsp;</td>
    <td bgcolor="#999999">&nbsp;</td>
    <td bgcolor="#999999">&nbsp;</td>
    <td bgcolor="#999999">&nbsp;</td>
    <td bgcolor="#999999">&nbsp;</td>
    <td bgcolor="#999999">&nbsp;</td>
    <td bgcolor="#999999">&nbsp;</td>
    <td bgcolor="#999999">&nbsp;</td>
    <td bgcolor="#999999">&nbsp;</td>
    <td bgcolor="#999999">&nbsp;</td>
    <td bgcolor="#999999">&nbsp;</td>
    <td bgcolor="#999999">&nbsp;</td>
    <td>&nbsp;</td>
    <td bgcolor="#999999">&nbsp;</td>
    <td bgcolor="#999999">&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
    <?php
	  }
	?>
  <?php
	//Subtotales por turno
			if(($viajes[1][$a]!=$viajes[1][$a+1]))
			{
	?>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td bgcolor="#666666">&nbsp;</td>
    <td bgcolor="#666666">&nbsp;</td>
    <td bgcolor="#666666">&nbsp;</td>
    <td bgcolor="#666666">&nbsp;</td>
    <td bgcolor="#666666">&nbsp;</td>
    <td bgcolor="#666666">&nbsp;</td>
    <td bgcolor="#666666">&nbsp;</td>
    <td bgcolor="#666666">&nbsp;</td>
    <td bgcolor="#666666">&nbsp;</td>
    <td bgcolor="#666666">&nbsp;</td>
    <td bgcolor="#666666">&nbsp;</td>
    <td bgcolor="#666666">&nbsp;</td>
    <td bgcolor="#666666">&nbsp;</td>
    <td bgcolor="#666666">&nbsp;</td>
    <td bgcolor="#666666">&nbsp;</td>
    <td bgcolor="#666666">&nbsp;</td>
    <td bgcolor="#666666">&nbsp;</td>
    <td>&nbsp;</td>
    <td bgcolor="#666666">&nbsp;</td>
    <td bgcolor="#666666">&nbsp;</td>
  </tr>
  <?php
	  }
	?>
  <?php
	  }
	?>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td bgcolor="#000000">&nbsp;</td>
    <td bgcolor="#000000">&nbsp;</td>
    <td bgcolor="#000000">&nbsp;</td>
    <td bgcolor="#000000">&nbsp;</td>
    <td bgcolor="#000000" align="center" style="color:#FFF"><strong><?php echo number_format($total_viajes, 0, '.', ','); ?></strong></td>
    <td bgcolor="#000000">&nbsp;</td>
    <td bgcolor="#000000">&nbsp;</td>
    <td bgcolor="#000000">&nbsp;</td>
    <td bgcolor="#000000">&nbsp;</td>
    <td bgcolor="#000000">&nbsp;</td>
    <td bgcolor="#000000">&nbsp;</td>
    <td bgcolor="#000000" align="center" style="color:#FFF"><strong><?php echo number_format($total_vol_primerkm, 0, '.', ','); ?></strong></td>
    <td bgcolor="#000000" align="center" style="color:#FFF"><strong><?php echo number_format($total_vol_kmsub, 0, '.', ','); ?></strong></td>
    <td bgcolor="#000000" align="center" style="color:#FFF"><strong><?php echo number_format($total_vol_kmadic, 0, '.', ','); ?></strong></td>
    <td bgcolor="#000000" align="center" style="color:#FFF"><strong><?php echo number_format($total_imp_primerkm, 2, '.', ','); ?></strong></td>
    <td bgcolor="#000000" align="center" style="color:#FFF"><strong><?php echo number_format($total_imp_kmsub, 2, '.', ','); ?></strong></td>
    <td bgcolor="#000000" align="center" style="color:#FFF"><strong><?php echo number_format($total_imp_adic, 2, '.', ','); ?></strong></td>
    <td>&nbsp;</td>
    <td bgcolor="#000000" align="center" style="color:#FFF"><strong><?php echo number_format($total_volumen, 0, '.', ','); ?></strong></td>
    <td bgcolor="#000000" align="center" style="color:#FFF"><strong><?php echo number_format($total_importe, 2, '.', ','); ?></strong></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>
</body>
</html>